var $disabledResults = $(".js-example-disabled-results");
$disabledResults.select2();