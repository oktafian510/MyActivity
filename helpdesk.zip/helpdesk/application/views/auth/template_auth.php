<?php $this->load->view('auth/template/auth_header');?>
<div id="wrapper">
     <?php echo $contents; ?>
</div>
<?php $this->load->view('auth/template/auth_footer');?>