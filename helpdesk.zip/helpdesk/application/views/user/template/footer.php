
    <!-- Bootstrap core JavaScript-->
    <script src="<?= base_url()?>assets/back/vendor/jquery/jquery.min.js"></script>
    <script src="<?= base_url()?>assets/back/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="<?=base_url()?>assets/back/vendor/bootstrap/js/bootstrap.bundle.js"></script>
    <script src="<?=base_url()?>assets/back/vendor/bootstrap/js/bootstrap-select.js"></script>
    <script src="<?=base_url()?>assets/back/vendor/bootstrap/js/bootstrap-select.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="<?= base_url()?>assets/back/vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="<?= base_url()?>assets/back/js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="<?= base_url()?>assets/back/vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="<?= base_url()?>assets/back/vendor/datatables/dataTables.bootstrap4.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="<?= base_url()?>assets/back/js/demo/datatables-demo.js"></script>

    <script src="<?=base_url()?>assets/back/js/hideshow.js"></script>
    <script src="<?=base_url()?>assets/back/js/select2.js"></script>
    <script src="<?=base_url()?>assets/back/js/select2.min.js"></script>
    <script src="<?=base_url()?>assets/back/js/autocomplete.js"></script>

    
    
  

</body>

</html>