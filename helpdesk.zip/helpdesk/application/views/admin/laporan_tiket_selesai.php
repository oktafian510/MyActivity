<!-- Content Wrapper -->
<div id="content-wrapper" class="d-flex flex-column">

<!-- Main Content -->
<div id="content">

    <!-- Topbar -->
    <?php $this->load->view('admin/template/navbar');?>
    <!-- End of Topbar -->

<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800"><b>Laporan Tiket Selesai</b></h1>
    <!-- DataTales Example -->
    <div class="card shadow mb-4 ">

        <div class="card-body">
            <div class="table-responsive">
                <div id="dataTable_wrapper" class="dataTables_wrapper dt-bootstrap4">
                    <div class="row">
                        <div class="col-sm-12">
                            <table class="table table-bordered dataTable" id="dataTable" width="100%" cellspacing="0" role="grid" aria-describedby="dataTable_info" style="width: 100%;">
                                <thead>
                                    <tr role="row">
                                        <th class="sorting sorting_asc" tabindex="0" aria-controls="dataTable" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Name: activate to sort column descending" style="width: 57px;">No</th>
                                        <th class="sorting" tabindex="0" aria-controls="dataTable" rowspan="1" colspan="1" aria-label="Position: activate to sort column ascending" style="width: 61px;">No. Tiket</th>
                                        <th class="sorting" tabindex="0" aria-controls="dataTable" rowspan="1" colspan="1" aria-label="Office: activate to sort column ascending" style="width: 49px;">Departemen</th>
                                        <th class="sorting" tabindex="0" aria-controls="dataTable" rowspan="1" colspan="1" aria-label="Office: activate to sort column ascending" style="width: 49px;">Masalah Utama</th>
                                        <th class="sorting" tabindex="0" aria-controls="dataTable" rowspan="1" colspan="1" aria-label="Office: activate to sort column ascending" style="width: 49px;">Keterangan Masalah</th>
                                        <th class="sorting" tabindex="0" aria-controls="dataTable" rowspan="1" colspan="1" aria-label="Office: activate to sort column ascending" style="width: 49px;">Solusi</th>
                                        <th class="sorting" tabindex="0" aria-controls="dataTable" rowspan="1" colspan="1" aria-label="Start date: activate to sort column ascending" style="width: 68px;">Tanggal Ajuan</th>
                                        <th class="sorting" tabindex="0" aria-controls="dataTable" rowspan="1" colspan="1" aria-label="Age: activate to sort column ascending" style="width: 31px;">Teknisi</th>
                                        <th class="sorting" tabindex="0" aria-controls="dataTable" rowspan="1" colspan="1" aria-label="Start date: activate to sort column ascending" style="width: 68px;">Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                        $no = 1;
                                        foreach ($tiket as $mhs):
                                            $idstatus = $mhs->STATUS_TIKET;
                                            if ($idstatus == 1) {
                                                $css = "badge badge-primary";
                                            } elseif ($idstatus == 2) {
                                                $css = "badge badge-secondary";
                                            } elseif ($idstatus == 3) {
                                                $css = "badge badge-info";
                                            } elseif ($idstatus == 4) {
                                                $css = "badge badge-success";
                                            } elseif ($idstatus == 5) {
                                                $css = "badge badge-warning";
                                            } elseif ($idstatus == 6) {
                                                $css = "badge badge-light";
                                            } elseif ($idstatus == 7) {
                                                $css = "badge badge-light";
                                            }	
                                        ?>
                                        <tr>
                                            <td><?php echo $no++ ?></td>
                                            <td><?php echo $mhs->ID_TIKET ?></td>
                                            <td><?php echo $mhs->NAMA_DEPARTEMEN ?></td>
                                            <td><?php echo $mhs->SUB_MASALAH ?></td>
                                            <td><?php echo $mhs->MASALAH ?></td>
                                            <td><?php echo $mhs->SOLUSI ?></td>
                                            <td><?php echo $mhs->TANGGAL ?></td>
                                            <td><?php echo $mhs->nama_user ?></td>
                                            <td><span class="<?= $css ?>"> <?= $mhs->STATUS ?></span></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- /.container-fluid -->
</div>
    <!-- End of Main Content -->

</div>

</div>
<!-- End of Content Wrapper -->