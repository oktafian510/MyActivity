const firebaseConfig = {
  apiKey: "AIzaSyB9pU5oAIvbkE3BLam-LvH0ZELkPqK38RI",
  authDomain: "bantubantuin-dev.firebaseapp.com",
  projectId: "bantubantuin-dev",
  storageBucket: "bantubantuin-dev.appspot.com",
  messagingSenderId: "320642068209",
  appId: "1:320642068209:web:eee6a4c27b78f0c34c0350",
  measurementId: "G-N3XD6YEMMF",
};

export default firebaseConfig;
