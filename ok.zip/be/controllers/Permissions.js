import Permissions from "../models/PermissionModel.js";

export const getPermission = async () => {};
